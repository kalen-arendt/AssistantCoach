
True Type Font: Arial Narrow 7 version 1.01


EULA
-==-
The font Arial Narrow 7 is freeware. You may use it for commercial use.


DESCRIPTION
-=========-
Simple narrow arial font. Cyrillic code page is included.

Files in arial_narrow_7.zip:
       	readme.txt     			this file;
        arial_narrow_7.ttf 		regular font;
	arial_narrow_7_screen.png	preview image.

Please visit http://www.styleseven.com/ for download our other software products as freeware as shareware.
We will welcome any useful suggestions and comments; please send them to ms-7@styleseven.com


NOTE
-==-
Please add back link to us as donation. Credit information is welcome.


-=========-
WHAT'S NEW?
 * Version 1.01, October 31 2022.
   * Some font metrics are changed.


AUTHOR
-====-
Sizenko Alexander
Style-7
http://www.styleseven.com
Created: July 12 2014