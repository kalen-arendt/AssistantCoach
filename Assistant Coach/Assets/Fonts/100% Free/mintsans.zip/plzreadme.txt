Thank you for downloading my font again.

I don't really have all too much to say,
only that I think this update delivers a
fair bit of much needed improvements.

If you discover any errors or wanna give
me some feedback, feel free to send me a
message on Twitter or via email.

Email: mail@pprmint.de
Twitter: https://twitter.com/npprmint

Future updates can be found on my Tumblr
blog: https://blog.pprmint.de/

Have fun with MintSans version 2.0!

┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬┤･ω･)ﾉ├┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬┴┬

Nick / pprmint.